export interface AdminAuthenticationStatus {
    username: string;
    password: string;
    adminAuthenticated: boolean;
  }